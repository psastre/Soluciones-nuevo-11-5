<div class="btndifer" role="dialog">
    <a href="#" class="btndif nosocioBtndif"> <span> Es mi 1er pedido</span><br/>Es la primera vez que hago un pedido a Soluciones.</a>
    <a href="#" class="btndif socioBtndif"><span>Soy cliente registrado</span><br/>Ya era cliente y ahora quiero hacer pedido de forma online</a>

  </div>

  <?php include_once("socioNoregPopup.php"); ?>