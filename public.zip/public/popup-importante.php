<div id="myModal" class="modal fade in" role="dialog" style="justify-content:center;">
    <div class="modal-dialog" style="width:70%; margin: auto;">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">IMPORTANTE</h4>
        </div>
        <div class="modal-body">
          <div class="row">

            <div class="col-sm-4">
              <img class="img-modal" src="img/icon-14.png" alt="">
              <h4 class="texto-modal">Nuestro servicio se brinda en toda la Capital Federal.</h4>
            </div>

            <div class="col-sm-4">
              <img class="img-modal" src="img/icon-17.png" alt="">
              <h4 class="texto-modal">Recepcion de pedidos, de lunes a viernes de 8 a 20hs</b></h4>
            </div>

            <div class="col-sm-4">
              <img class="img-modal" src="img/icon-1.png" alt="">
              <h4 class="texto-modal">Una vez hecho el pedido el tecnico se comunicara con usted a la brevedad</h4>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Entendido</button>
        </div>
      </div>

    </div>
  </div>